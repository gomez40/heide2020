# Assessment

1. Since this is a collaborative assesment task you are given 1 hour to finish the expected result
2. Download this repo as your starter file
4. Create a personalize project folder and name it using the following format Lastname_Firstname_Assessment.
5. Place the style.css file in a folder "css" to organize your file structure
6. Once your through with you assessment push your solution in your personal github profile and be guided on what to submit given on the LMS.

Output:

![alt text](https://github.com/cfbautistaofficial01/Assessment/blob/main/assessment_output.png)

Good luck and God Speed everyone!
